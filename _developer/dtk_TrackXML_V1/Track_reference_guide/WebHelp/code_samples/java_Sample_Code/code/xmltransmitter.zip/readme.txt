-- If you are performing an IBM implementation use the XmlTransmitterIBM.java file.

-- If you are performing an Sun Microsystems implementation use the XmlTransmitterSUN.java file.


Go to the "Working with Java Sample Code" page for additional information.

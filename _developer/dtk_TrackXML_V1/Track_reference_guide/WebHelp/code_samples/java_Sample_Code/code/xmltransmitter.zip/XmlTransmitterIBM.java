import java.io.*;
import java.util.*;
import java.net.*;
//import IBM's SSLight package to deal with SSL
import com.ibm.sslite.*;
import com.ibm.sslite.https.*;

/**
 * The XmlTransmitter will transmit an HTTP/HTTPS post with the StringBuffer provided as 
 * the data of the post message.  The XmlTransmitter must be constructed with a URL or
 * IP address and a protocol to use for transmitting the message.
 */
public class XmlTransmitterIBM
{
	private String hostname;
	private String protocol;
	private String prefix;
	private String proxyHost;
	private String proxyPort;
	private String keyLocation;
	private StringBuffer XmlIn;
	private StringBuffer XmlOut;
	private static java.lang.String username;
	private static java.lang.String password;
	private static java.lang.String encodedPass;

	private final static java.lang.String __CLASS__ = "XMLTransmitter::";
	private final static java.lang.String METHOD_ContactService = "contactService(String, String)";
	private final static java.lang.String METHOD_readURLConnection = "readURLConnection(URLConnection)";
/**
 * Constructs a new XmlTransmitter for purposes of HTTPS posts not inhibited by
 * a Proxy Server or FireWall.
 * @param hostname java.lang.String
 * @param protocol java.lang.String
 * @param keyring java.lang.String
 * 
 */
public XmlTransmitterIBM(String hostname, String protocol, String keyring)
{
	this.hostname = hostname.trim();
	this.protocol = protocol.trim();
	this.keyLocation = keyring;
}
/**
 * Constructs a new XmlTransmitter for purposes of HTTPS posts and allows the addition of
 * Proxy information for access through a Proxy Server or FireWall.  The software assumes
 * Basic Authentication is used by 99% of Proxy Servers and Firewalls.
 * @param hostname java.lang.String
 * @param protocol java.lang.String
 * @param proxy java.lang.String
 * @param port java.lang.String
 * @param keyring java.lang.String
 * 
 */
public XmlTransmitterIBM(String hostname, String protocol, String keyring, String proxy, String port, String username, String password)
{
	this.hostname = hostname.trim();
	this.protocol = protocol.trim();
	this.keyLocation = keyring;
	if (proxy != null && port != null)
	{
		if (protocol.equalsIgnoreCase("https"))
		{
			System.getProperties().put("https.proxyHost", proxy);
			System.getProperties().put("https.proxyPort", port);
			this.proxyHost = proxy;
			this.proxyPort = port;
			this.username = username;
			this.password = password;
		} else
		{
			System.getProperties().put("proxySet", "true");
			System.getProperties().put("http.proxyHost", proxy);
			System.getProperties().put("http.proxyPort", port);
			java.lang.String pass = username + ":" + password;
			// This handles Basic authentication only (99% of situations are basic)
			this.encodedPass = "Basic " + (Base64.base64Encode(pass));
		}
	}

}
/**
 * This method is used to send the XmlTransmitter information to a designated service.  
 * @param service java.lang.String
 * @param prefix java.lang.String
 * @throws java.lang.Exception
 */
public void contactService(String service, String prefix) throws Exception
{
System.out.println(__CLASS__ + METHOD_ContactService + "******************************** Started " + service + " " + new Date().toString() + " *************************************");
		try
	{
		// Create new URL and connect
		if (protocol.equalsIgnoreCase("https"))
		{
			//use IBM's SSLight to deal with SSL
			setHttpsContext(keyLocation, "sslight");
	
		}
		System.out.println("contact service: " + protocol + "://" + hostname + "/" + prefix + "/" + service);
		URL url = new URL(protocol + "://" + hostname + "/" + prefix + "/" + service);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		System.out.println(__CLASS__ + METHOD_ContactService + "Establishing connection with " + url.toString());

		// Setup HTTP POST parameters
		connection.setDoOutput(true);
		connection.setDoInput(true);
		connection.setUseCaches(false);
		if (this.encodedPass != null)
			connection.setRequestProperty("Proxy-Authorization", this.encodedPass);
		
		// Get POST data from input StringBuffer containing an XML document 
		String queryString = XmlIn.toString();

		// POST data
		OutputStream out = connection.getOutputStream();
		out.write(queryString.getBytes());
		System.out.println(__CLASS__ + METHOD_ContactService + "Transmission sent to " + url.toString() + ":\n" + queryString);
		out.close();

		// get data from URL connection and return the XML document as a StringBuffer
		String data = "";
		try
		{
		 data = readURLConnection(connection);
		}catch (Exception e)
		{
			System.out.println("Eror in reading URL Connection" + e.getMessage());
			throw e;
		}
		System.out.println("Response = " + data);
		XmlOut = new StringBuffer(data);
	} catch (Exception e1)
	{
		System.out.println("Error sending data to server" + e1.toString());
	} finally
	{
		System.out.println(__CLASS__ + METHOD_ContactService + "******************************** Finished " + service + " " + new Date().toString() + " *************************************");
	}
}
/**
 * This method returns the xml response, from the XmlTransmitter's URL, to the caller of method.
 * @return java.lang.StringBuffer
 */
public StringBuffer getXml()
{
	return XmlOut;
}
/**
* main() method reads the xml request file, 
* and outputs the xml response file.
* protocol, hostname, and etc. are from
* the property file.
*
*/
public static void main(String args[]) 
{
	XmlTransmitterIBM xTrans=null;
	StringBuffer in;
	StringBuffer out = new StringBuffer();
	
	if (args.length!=5)
	{
		System.out.println("Usage: XmlTransmitter <service> <config filename> <Access request filename> <Service request filename> <output filename>");
		System.exit(1);
	}
	
	StringBuffer sb = new StringBuffer();
	Properties props = new Properties();
	//Read the data from the config file
	try
	{
	 FileInputStream configIn = new FileInputStream(args[1]);
	 props.load(configIn);
	 configIn.close();
	}catch(Exception e)
	{
		System.out.println("Cannot read config file " + e.getMessage());
		System.exit(1);
	}
	String prot = props.getProperty("Protocol");
	String hostname = props.getProperty("Hostname");
	String URLPrefix = props.getProperty("Prefix");
	String keyring = props.getProperty("KeyRing");
	String proxyHost = props.getProperty("ProxyHost");
	String proxyPort = props.getProperty("ProxyPort");
	String proxyUser = props.getProperty("ProxyUser");
	String proxyPassword = props.getProperty("ProxyPassword");
	//build XmlTransmitter
	try
	{
		if (proxyHost == null)  //HTTP request does not through a Proxy Server or FireWall
		{
			xTrans = new XmlTransmitterIBM(hostname, prot, keyring);
		} else   //HTTP request will access through a Proxy Server or FireWall
		{
			xTrans = new XmlTransmitterIBM(hostname, prot, keyring, proxyHost, proxyPort, proxyUser, proxyPassword);
		}
	}catch(Exception e)
	{
		System.out.println("Cannot build XmlTransmitter: "+e.toString());
		System.exit(1);
	}
	//read the xml request file
	try
	{
		in = readInputFile(args[2]);
		in.append(readInputFile(args[3]));
		xTrans.setXml(in);
	}catch(Exception e)
	{
		System.out.println("Cannot read the xml request file: "+ e.toString());
		System.exit(1);
	}
	try
	{
		xTrans.contactService(args[0],URLPrefix);
		out = xTrans.getXml();
	}catch(Exception e)
	{
		System.out.println("Cannot contact the service: "+ e.toString());
		System.exit(1);
	}
	//write the xml response to a file
	try
	{
		writeOutputFile(out, args[4]);
	}catch(Exception e)
	{
		System.out.println("Cannot write the xml response to file: "+ e.toString());
		System.exit(1);
	}
		System.exit(0);
}
/**
 * Reads an input file to a String
 * @return java.lang.String
 * @param file java.lang.String
 */
public static StringBuffer readInputFile(String file) throws Exception
{
	StringBuffer xml = new StringBuffer();
	InputStreamReader in = new java.io.InputStreamReader(new FileInputStream(file));
	LineNumberReader lineReader = new LineNumberReader(in);
	String line_xml = null;
	while ((line_xml = lineReader.readLine()) != null)
	{
		xml.append(line_xml);
	}
	lineReader.close();
	return xml;
}
/**
 * This method read all of the data from a URL conection to a String
 */

private static String readURLConnection(URLConnection uc) throws Exception
{
	StringBuffer buffer = new StringBuffer();
	BufferedReader reader = null;
	try
	{
		reader = new BufferedReader(new InputStreamReader(uc.getInputStream()));
		String line = null;
		int letter = 0;
		while ((letter = reader.read()) != -1)
			buffer.append((char) letter);
	} catch (Exception e)
	{
		System.out.println("Cannot read from URL" + e.toString());
		throw e;
	} finally
	{
		try
		{
			reader.close();
		} catch (IOException io)
		{
			System.out.println("Error closing URLReader!");
			throw io;
		}
	}
	return buffer.toString();
}
/**
 * This method adds HTTPS protocol handler to system properties,
 * set up the context to be used by HTTPS handler, and sets up
 * a callback for proxy authentication.
 *
 * @param file java.lang.String
 * @param psswd java.lang.String
 */
private static void setHttpsContext(String file, String psswd) throws Exception
{
	// This commented line enables a context version that is extremely trusty
   	com.ibm.sslite.SSLContext context = new com.ibm.sslite.SSLContext();
	
	SSLPKCS12Token token = new SSLPKCS12Token();
	FileInputStream kin = null;
	try
	{
		byte[] data = new byte[ (int) new File(file).length()];
		(kin = new FileInputStream(file)).read(data);
		token.open(data, psswd);
	} catch (Exception e)
	{
		try
		{
			kin.close();
		}
 catch (Exception ex)
		{
		}				System.out.println("https: Cannot load key ring: " + e);
		throw e;
	}
	context.importToken(token);

	// Add the HTTPS protocol handler to system properties
	String p = "com.ibm.sslite";
	String s = ((s = System.getProperty("java.protocol.handler.pkgs")) != null ? s + "|" + p : p);
	System.getProperties().put("java.protocol.handler.pkgs", s);
	// Setup the context to be used by HTTPS handler
	com.ibm.sslite.https.SSLNetworkClient.setContext(context);
	
	// Resync system properties with HTTPS handler
	// - do this anytime you change system properties related to HTTPS handler
	com.ibm.sslite.https.HttpsClient.resetProperties();
	// Setup a callback for proxy authentication (pops up a dialog box)
	com.ibm.sslite.https.HttpsURLConnection.setDefaultAuthenticator(new Proxy(username, password));
	// HTTPS is up and ok now.
	
}
/**
 * Setter for purposes of giving the XmlTransmitter the request data.
 * @param input java.lang.StringBuffer
 */
public void setXml(StringBuffer input)
{
	this.XmlIn = input;
}
/**
 * @param str java.lang.String
 * @param file java.lang.String
 */
public static void writeOutputFile(StringBuffer str, String file) throws Exception{
	FileOutputStream fout = new FileOutputStream(file);
	fout.write(str.toString().getBytes());
	fout.close();

}
}

This is a quick note to describe the documentation process for
XML OnLine Tools and Web Services. There are a few things you
need to do to get that process running on your computer.


ASSETS

First, get the various required assets from source control. There
are a bunch of assets checked in there, but really only a few are
essential. Those are

Fonts

The templates, styles, and macros are optimized for very particular
fonts. There are a total of six fonts used in the documents, though
three of them come standard with Windows.

  1. Myriad Pro
  2. Myriad Pro Web
  3. Bitstream Vera
  4. Courier New (standard with Windows)
  5. WingDings (standard with Windows)
  6. Webdings (standard with Windows)

You'll find other fonts in the assets directory in source control,
but those fonts were used for older (FrameMaker) documents and are
not required for the new Word formats.

Templates

The two MS Word templates in the assets directory that are required
are

  1. XOLT Developers Guide.dot
  2. XOLT Web Services Developers Guide.dot

Copy these templates to whereever you have MS Word templates on 
your system. Generally, that's in the C:\Documents and Setttings\
[user]\Application Data\Microsoft\Templates folder.

Other templates in source control are older versions and no longer
needed. The macros that control the documentation process are
included in the templates. They're fairly reasonable visual basic
for applications (VBA) if you need to make any adjustments, but
no changes should be required.

Transforms

There is one XSL Transform stylesheet that is essential to the
process, xmldoc.xsl. Copy this transforms to aconvenient location.
When you run the MS Word macros, they will ask you for the transform.

Other transform stylesheets are older versions and no longer needed.

Although you shouldn't have to modify these stylesheets, they are
reasonably well commented, so anyone familiar with XSL shouldn't
have too much trouble making any needed adjustments.

Word Content

The Word Content folder in source control includes many pre-written
sections (primarily appendices) that can be added on to documents
as required. Much of this content will change (e.g. as UPS defines
new service codes), so you may need to update these documents before
incorporating them.


TOOLS

The only essential tools are MS Office 2003, specifically Word, and
Adobe Acrobat Professional 6.0 or later. If you need to create or
modify any illustrations you'll also need Visio and Powerpoint
from Office 2003. (You do need them both.)

The first page or slide in all of the Visio and Powerpoint files
in source control explains how to incorporate the illustrations.
It's slightly complicated, but unfortunately required because Visio
and Word use different font formats (OpenType vs. TrueType). If
you don't follow the process, the documents will be very pixelated
when viewed onscreen (though they'll look fine printed).

Also, you'll need to be sure that the latest MSXML library from
Microsoft is installed on your computer. It probably already is,
but if not, you can download a version from Microsoft's web site.
(It's free. Search microsoft.com for MSXML to find it.) The latest
version as of this writing is msxml6.msi, and a copy is in the
Tools folder under the Assets. Double-click to install it.


INPUT

Inputs to the documentation process are annotated WSDL or XSD
files. These are generally available from the development team,
but the development versions do not have annotations. You'll have
to add the annotations based on information from the Interface
Specifications. Instead of trying to explain the process here,
I'd recommend taking a look at some examples in source control.
It's actually quite straightforward. If you have access to an
XML editor (I recommend <oXygen/>), the annotation process is
even simpler. BTW, the resulting annotated files are prefectly
legal WSDL or XSD files, so, if the development team is amenable,
you could give them back to the developers and have them use
the annotated files from that point forward. So long as the
annotation was kept up to date, that would save later writers
the effort of adding the annotation.


GENERATING DOCUMENTS

You should always begin a document using the File->New... menu
in Word and then selecting the appropriate template. DO NOT
START WITH AN EXISTING DOCUMENT AND MODIFY IT. Starting with a
new document is the only way to ensure that all the document's
properties are set up correctly.

When you create a new document, there will be a big text box on
the front page with instructions about how to proceed. The
process is quite simple, and mostly consists of clicking a few
buttons on the toolbar. The instructions in the template will
also guide you through the process of creating the PDF files.
